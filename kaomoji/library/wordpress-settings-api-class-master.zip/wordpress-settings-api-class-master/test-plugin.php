<?php
/*
 Plugin Name: Settings API Class Test
 Version: 0.4.2
 Plugin URI: https://github.com/herewithme/wordpress-settings-api-class
 Description: Test all feature of settings API
 Author: Amaury Balmer
 Author URI: https://github.com/herewithme/
 Domain Path: languages
 Network: false
 Text Domain: wedevs
 */

require(dirname(__FILE__) . '/settings-api.php');
//require(dirname(__FILE__) . '/procedural-example.php');